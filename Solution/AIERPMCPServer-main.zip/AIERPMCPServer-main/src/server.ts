// Importing required packages
import express, { Request, Response } from "express"; // Express server for HTTP handling
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js"; // MCP server core from ModelContextProtocol SDK
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js"; // Streamable transport adapter for HTTP integration
import { z } from "zod"; // For input/output validation schemas (not used here but useful for robust design)

// Initialize a new MCP Server instance
const server = new McpServer({
  name: "ISDAIERPMCP", // Custom server name (used for identification/logging)
  version: "1.0.0",            // MCP contract versioning
});

// ==============================================
// Step 1: Reusable Access Token Generator for D365 FO
// ==============================================

/**
* Fetches a bearer token from Azure AD using client credentials flow
* for calling D365 FO OData APIs.
* Environment variables must contain:
*  - TENANTID: Azure Active Directory tenant ID
*  - CLIENTID: Azure app registration client ID
*  - CLIENTSECRET: App registration secret
*  - D365RESOURCE: Base URL of the D365 FO environment (e.g., https://xyz.operations.dynamics.com)
# For classic Application Insights
*AI_APP_ID="0675e78d-5ba6-4f64-b667-acce976ce8e3"
*AI_API_KEY="47g06awl2c5c5lkmxqixtm12a4f2crpm2qkbrumu"

*/
  async function getAccessToken() {
  const tenantId = process.env.TENANTID!;
  const clientId = process.env.CLIENTID!;
  const clientSecret = process.env.CLIENTSECRET!;
  const resource = process.env.D365RESOURCE!;
  const tokenUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/token`;

  // Construct OAuth 2.0 token request parameters
  const tokenParams = new URLSearchParams();
  tokenParams.append("grant_type", "client_credentials");
  tokenParams.append("client_id", clientId);
  tokenParams.append("client_secret", clientSecret);
  tokenParams.append("resource", resource);

  // Call Azure AD to retrieve access token
  const tokenResponse = await fetch(tokenUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: tokenParams,
  });

  // Throw error if token retrieval fails
  if (!tokenResponse.ok) {
    const error = await tokenResponse.text();
    throw new Error(`Token fetch failed: ${error}`);
  }

  // Extract access token from successful response
  const tokenData = await tokenResponse.json();
  return tokenData.access_token;
}

// ==============================================
// Step 2: MCP Tool to Fetch Customer Groups from D365 FO
// ==============================================

/**
* MCP Tool to fetch customer groups using a secured OData call.
* This is exposed to Copilot Studio as a callable tool named "get-customer-groups".
*/
const getCustomerGroups = server.tool(
  "get-customer-groups", // Identifier used by Copilot Studio
  "Fetch customer groups from D365FO using access token", // Tool description for LLM awareness

  async () => {
    const resource = process.env.D365RESOURCE!; // D365 FO environment URL
    const accessToken = await getAccessToken(); // Get valid bearer token

    // Compose full OData URL for fetching customer groups
    const d365Url = `${resource}/data/CustomerGroups`;

    // Perform secured API call to D365 FO OData endpoint
    const apiResponse = await fetch(d365Url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`, // Required auth header
        Accept: "application/json",              // Expect JSON response
      },
    });

    // Handle failure from D365 FO
    if (!apiResponse.ok) {
      const apiError = await apiResponse.text();
      throw new Error(`D365 API call failed: ${apiError}`);
    }

    // Extract customer group data from D365 FO response
    const apiData = await apiResponse.json();

    // Format the result for Copilot Studio output
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(apiData, null, 2), // Prettified JSON output
        },
      ],
    };
  }
);

// ==============================================
// Step 2: MCP Tool to Fetch metadata from D365 FO
// ==============================================

/**
* MCP Tool to fetch metadata using a secured OData call.
* This is exposed to Copilot Studio as a callable tool named "get-metadata".
*/
const getMetadata = server.tool(
  "get-metadata", // Identifier used by Copilot Studio
  "Fetch metadata from D365FO using access token", // Tool description for LLM awareness

  async () => {
    const resource = process.env.D365RESOURCE!; // D365 FO environment URL
    const accessToken = await getAccessToken(); // Get valid bearer token

    // Compose full OData URL for fetching customer groups
    const d365Url = `${resource}/data`;

    // Perform secured API call to D365 FO OData endpoint
    const apiResponse = await fetch(d365Url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`, // Required auth header
        Accept: "application/json",              // Expect JSON response
      },
    });

    // Handle failure from D365 FO
    if (!apiResponse.ok) {
      const apiError = await apiResponse.text();
      throw new Error(`D365 API call failed: ${apiError}`);
    }

    // Extract metadata data from D365 FO response
    const apiData = await apiResponse.json();

    // Format the result for Copilot Studio output
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(apiData, null, 2), // Prettified JSON output
        },
      ],
    };
  }
);
// ==============================================
// Step 3: MCP Tool to Fetch Depreciation Proposal from D365 FO
// ==============================================

/**
* MCP Tool to fetch Depreciation Proposal using a secured OData call.
* This is exposed to Copilot Studio as a callable tool named "get-depreciation-proposal".
*/
const getDepreciationPoposal = server.tool(
  "get-depreciation-proposal", // Identifier used by Copilot Studio
  "Fetch Depreciation Proposal from D365FO using access token", // Tool description for LLM awareness

  async () => {
    const resource = process.env.D365RESOURCE!; // D365 FO environment URL
    const accessToken = await getAccessToken(); // Get valid bearer token

    // Compose full OData URL for fetching Depreciation Proposal
    const d365Url = `${resource}/data/DepreciationProposalRuns`;

    // Perform secured API call to D365 FO OData endpoint
    const apiResponse = await fetch(d365Url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`, // Required auth header
        Accept: "application/json",              // Expect JSON response
      },
    });

    // Handle failure from D365 FO
    if (!apiResponse.ok) {
      const apiError = await apiResponse.text();
      throw new Error(`D365 API call failed: ${apiError}`);
    }

    // Extract Depreciation Poposal data from D365 FO response
    const apiData = await apiResponse.json();

    // Format the result for Copilot Studio output
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(apiData, null, 2), // Prettified JSON output
        },
      ],
    };
  }
);
// ==============================================
// MCP Tool to Fetch Customer Primary Activity from D365 FO through Odata Action
// ==============================================

/**
* MCP Tool to Fetch Customer Primary Activity from D365 FO through Odata Action using a secured OData call.
* This is exposed to Copilot Studio as a callable tool named "get-customer-primary-activity".
*/
const getCustomerPrimaryActivity = server.tool(
    "get-customer-primary-activity", // Identifier used by Copilot Studio
    "Fetch Customer Primary Activity from D365FO using access token", // Tool description for LLM awareness
    {
        activityNumber: z.string().describe("The activity number to query for customer primary activity"),
    },

    async ({activityNumber}) => {
    const resource = process.env.D365RESOURCE!; // D365 FO environment URL
    const accessToken = await getAccessToken(); // Get valid bearer token

    // Compose full OData URL for fetching customer account using primary activity
    const d365Url = `${resource}/data/ISDPayPredPredictionResultActivities/Microsoft.Dynamics.DataEntities.findCustPrimaryActivity`;

    // Prepare request payload
    const requestBody = {
      _activityNumber: activityNumber
    };

    // Perform secured API call to D365 FO OData endpoint
    const apiResponse = await fetch(d365Url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`, // Required auth header
        Accept: "application/json",              // Expect JSON response
        "Content-Type": "application/json", 
      },
      body: JSON.stringify(requestBody),      // attach JSON body
    });

    // Handle failure from D365 FO
    if (!apiResponse.ok) {
      const apiError = await apiResponse.text();
      throw new Error(`D365 API call failed: ${apiError}`);
    }

    // Extract customer primary activity account number from D365 FO response
    const apiData = await apiResponse.json();

    // Format the result for Copilot Studio output
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(apiData, null, 2), // Prettified JSON output
        },
      ],
    };
  }
);
//====== Batch API endpoint - Start  ========
//====== Set Batch Job To Waiting API - Start ========
const setBatchJobToWaiting = server.tool(
  "set-batch-job-to-waiting", // Identifier for Copilot Studio
  "Set a batch job to waiting status in Dynamics 365 Finance and Operations", // Description for Copilot
  {
    batchJobId: z.string().describe("Provide the Batch Job ID to be updated"),
  },

  async ({ batchJobId }) => {
    const resource = process.env.D365RESOURCE!; // D365 FO base URL
    const accessToken = await getAccessToken(); // Get Bearer token

    // Validate and convert to number
    const parsedJobId = Number(batchJobId);
    if (isNaN(parsedJobId)) {
      throw new Error(`Invalid Batch Job ID: "${batchJobId}" is not a number.`);
    }
    
    // Compose full OData URL for the batch API
    const d365Url = `${resource}/data/BatchJobs/Microsoft.Dynamics.DataEntities.SetBatchJobToWaiting`;

    // Request payload
    const requestBody = {
      batchJobId: Number(batchJobId),
    };

    // Make secure API call
    const apiResponse = await fetch(d365Url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    });

    // Handle errors
    if (!apiResponse.ok) {
      const errorText = await apiResponse.text();
      throw new Error(`SetBatchJobToWaiting API failed: ${errorText}`);
    }

    // Parse and return response
    const apiData = await apiResponse.json();

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(apiData, null, 2),
        },
      ],
    };
  }
);
//====== Set Batch Job To Waiting API - END ========
//====== Batch API endpoint - END ========
/**
* MCP Tool to query classic Application Insights using REST API.
* This is exposed to Copilot Studio as a callable tool named "ai-classic-query".
*
* Docs:
* - Query endpoint & schema: https://learn.microsoft.com/en-us/rest/api/application-insights/query/get?view=rest-application-insights-v1
* - Application ID & API key (API Access blade): https://learn.microsoft.com/en-us/rest/api/application-insights/
*/
const aiClassicQuery = server.tool(
  "ai-classic-query", // Identifier used by Copilot Studio
  "Run a KQL query against classic Application Insights via API key", // Tool description for LLM awareness

  async () => {
    // Required env vars:
    //   AI_APP_ID:  Application Insights "Application ID" (from API Access)
    //   AI_API_KEY: Application Insights API key (from API Access)
    // Optional:
    //   AI_KQL_QUERY: KQL to run (default provided below)
    //   AI_TIMESPAN: ISO8601 timespan (e.g., "PT1H" or "2024-01-01T00:00:00Z/2024-01-02T00:00:00Z")
    const appId = process.env.AI_APP_ID!;
    const apiKey = process.env.AI_API_KEY!;
    const kql = process.env.AI_KQL_QUERY;
    const timespan = process.env.AI_TIMESPAN;

    if (!appId) throw new Error("Missing AI_APP_ID environment variable");
    if (!apiKey) throw new Error("Missing AI_API_KEY environment variable");

    // Compose classic Application Insights query endpoint
    const aiUrl = `https://api.applicationinsights.io/v1/apps/${appId}/query`;

    // Perform secured API call to classic Application Insights (API key auth)
    const body: Record<string, unknown> = { query: kql };
   // if (timespan) body.timespan = timespan;

    const apiResponse = await fetch(aiUrl, {
      method: "POST",
      headers: {
        "x-api-key": apiKey,                // Required auth header for classic API
        "Content-Type": "application/json",
        Accept: "application/json",         // Expect JSON response
      },
      body: JSON.stringify(body),
    });

    // Handle failure from Application Insights API
    if (!apiResponse.ok) {
      const apiError = await apiResponse.text();
      throw new Error(`Application Insights API call failed: ${apiError}`);
    }

    // Extract analytics data from the response
    const apiData = await apiResponse.json();

    // Format the result for Copilot Studio output
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(apiData, null, 2), // Prettified JSON output
        },
      ],
    };
  }
);

// ==========================
// Setup Express and Transport
// ==========================

const app = express();
app.use(express.json()); // Middleware to parse incoming JSON requests

// Define the streamable transport for the MCP server
const transport: StreamableHTTPServerTransport =
  new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined, // Stateless session (no per-user session context)
  });

// --------------------------
// Setup and connect MCP server
// --------------------------
const setupServer = async () => {
  await server.connect(transport); // Link MCP logic to the transport layer
};

// --------------------------
// Define HTTP endpoints
// --------------------------

// POST endpoint to handle all valid MCP JSON-RPC requests
app.post("/mcp", async (req: Request, res: Response) => {
  console.log("Received MCP request:", req.body);
  try {
    await transport.handleRequest(req, res, req.body); // Pass request to MCP engine
  } catch (error) {
    console.error("Error handling MCP request:", error);
    if (!res.headersSent) {
      res.status(500).json({
        jsonrpc: "2.0",
        error: {
          code: -32603,
          message: "Internal server error",
        },
        id: null,
      });
    }
  }
});

// Block GET requests on /mcp (only POST supported for JSON-RPC)
app.get("/mcp", async (req: Request, res: Response) => {
  console.log("Received GET MCP request");
  res.writeHead(405).end(
    JSON.stringify({
      jsonrpc: "2.0",
      error: {
        code: -32000,
        message: "Method not allowed. NT server",
      },
      id: null,
    })
  );
});

// Block DELETE requests on /mcp (not applicable for JSON-RPC)
app.delete("/mcp", async (req: Request, res: Response) => {
  console.log("Received DELETE MCP request");
  res.writeHead(405).end(
    JSON.stringify({
      jsonrpc: "2.0",
      error: {
        code: -32000,
        message: "Method not allowed.",
      },
      id: null,
    })
  );
});

// --------------------------
// Start the Express server
// --------------------------
const PORT = process.env.PORT || 3000;
setupServer()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`MCP Streamable HTTP Server listening on port ${PORT}`);
    });
  })
  .catch((error) => {
    console.error("Failed to set up the server:", error);
    process.exit(1);
  });
